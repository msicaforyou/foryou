package com.angopapo.datoo.modules.autoimageslider.IndicatorView.draw.data;

public enum Orientation {HORIZONTAL, VERTICAL}
