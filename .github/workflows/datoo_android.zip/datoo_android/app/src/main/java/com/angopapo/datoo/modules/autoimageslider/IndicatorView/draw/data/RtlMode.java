package com.angopapo.datoo.modules.autoimageslider.IndicatorView.draw.data;

public enum RtlMode {On, Off, Auto}