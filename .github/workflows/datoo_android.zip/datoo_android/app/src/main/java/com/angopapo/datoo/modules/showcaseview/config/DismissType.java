package com.angopapo.datoo.modules.showcaseview.config;

public enum DismissType {
    outside, anywhere, targetView
}