package com.angopapo.datoo.modules.merlin;

interface RequestMaker {
    Request head(Endpoint endpoint);
}
