package com.angopapo.datoo.app;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.angopapo.datoo.R;
import com.angopapo.datoo.helpers.QuickHelp;


public class BaseActivity extends AppCompatActivity {

    @Override
    public void finish() {
        super.finish();
        overridePendingTransitionExit();
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransitionEnter();

        if (!QuickHelp.isInternetAvailable(this)){

            QuickHelp.noInternetConnect(this);
        }
    }

    /**
     * Overrides the pending Activity transition by performing the "Enter" animation.
     */
    protected void overridePendingTransitionEnter() {
        overridePendingTransition(R.anim.slide_from_right, R.anim.slide_to_left);
    }

    /**
     * Overrides the pending Activity transition by performing the "Exit" animation.
     */
    protected void overridePendingTransitionExit() {
        overridePendingTransition(R.anim.slide_from_left, R.anim.slide_to_right);
    }

}