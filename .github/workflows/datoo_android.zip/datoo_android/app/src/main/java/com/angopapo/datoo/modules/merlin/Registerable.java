package com.angopapo.datoo.modules.merlin;

interface Registerable {
}
