package com.angopapo.datoo.modules.cardstackview;

public enum StackFrom {
    None,
    Top,
    TopAndLeft,
    TopAndRight,
    Bottom,
    BottomAndLeft,
    BottomAndRight,
    Left,
    Right,
}
