package com.angopapo.datoo.modules.autoimageslider;

public enum IndicatorAnimations {
    WORM,
    THIN_WORM,
    COLOR,
    DROP,
    FILL,
    NONE,
    SCALE,
    SCALE_DOWN,
    SLIDE,
    SWAP,
}
