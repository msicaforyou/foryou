package com.angopapo.datoo.modules.showcaseview.listener;

import android.view.View;

public interface GuideListener {
    void onDismiss(View view);
}
