package com.angopapo.datoo.modules.merlin;

public interface Bindable extends Registerable {
    void onBind(NetworkStatus networkStatus);
}
