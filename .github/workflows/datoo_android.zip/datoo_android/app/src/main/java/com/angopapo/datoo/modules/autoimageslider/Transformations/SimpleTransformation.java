package com.angopapo.datoo.modules.autoimageslider.Transformations;

import androidx.viewpager.widget.ViewPager;
import android.view.View;

public class SimpleTransformation implements ViewPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}