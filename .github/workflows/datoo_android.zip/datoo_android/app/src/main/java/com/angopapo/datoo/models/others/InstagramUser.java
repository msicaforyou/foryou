package com.angopapo.datoo.models.others;

public class InstagramUser {
    public static String user_id;
    public static String access_token;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        InstagramUser.user_id = user_id;
    }

    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        InstagramUser.access_token = access_token;
    }
}
