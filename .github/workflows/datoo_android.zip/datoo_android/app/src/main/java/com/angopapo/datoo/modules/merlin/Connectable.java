package com.angopapo.datoo.modules.merlin;

public interface Connectable extends Registerable {
    void onConnect();
}
