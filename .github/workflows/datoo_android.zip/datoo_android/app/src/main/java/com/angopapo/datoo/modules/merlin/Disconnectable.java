package com.angopapo.datoo.modules.merlin;

public interface Disconnectable extends Registerable {
    void onDisconnect();
}
