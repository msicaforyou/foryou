package com.angopapo.datoo.modules.showcaseview.config;

public enum Gravity {
    auto, center
}

