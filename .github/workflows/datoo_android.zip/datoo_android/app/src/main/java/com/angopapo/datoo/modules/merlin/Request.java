package com.angopapo.datoo.modules.merlin;

interface Request {
    int getResponseCode();
}
