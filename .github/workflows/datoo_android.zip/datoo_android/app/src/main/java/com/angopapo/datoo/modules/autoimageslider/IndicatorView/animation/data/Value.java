package com.angopapo.datoo.modules.autoimageslider.IndicatorView.animation.data;

public interface Value {/*empty*/}
