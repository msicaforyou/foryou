package com.angopapo.datoo.modules.discretescrollview.transform;

import android.view.View;

public interface DiscreteScrollItemTransformer {
    void transformItem(View item, float position);
}
